<?php

$serverUrl = "https://inshorts.deta.dev/news?";

?>