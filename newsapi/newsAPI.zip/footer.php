    <footer class="jumbotron text-center text-muted" style="margin-bottom:0">
        <p>created by Nife.</p>
    </footer>

        <script src="scripts/bootstrap.bundle.min.js"></script>
        <script src="scripts/jquery.slim.min.js"></script>
        <script src="scripts/popper.min.js"></script>

 </body>
</html>