<?php require_once('utility/db_connection.php'); ?>

<?php

//initialize the session.
if (session_status() != PHP_SESSION_ACTIVE);
session_start();

//conditional session destroy
$userInSession = $_SESSION['userInSession'];
$fullname = $_SESSION['fullname'];

if ($userInSession == NULL) {
  header('location:signin.php');
}

//write query for all hobbies
$sql = $conn->query("SELECT * FROM tb_hobbies WHERE account_id = $userInSession");

//fetch the resulting rows as an array.
$tb_hobbies = $sql->fetch_all();

// $errors = array('err' => '');

$hobby = $status = '';


if (isset($_POST['hobby'])) {

  $hobby_name = $_POST['hobby_name'];

  $status = $_POST['status'];

    $hobby_name = mysqli_real_escape_string($conn, $_POST['hobby_name']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    //create sql:
    $insert_hobby = "INSERT INTO tb_hobbies (hobby_name,status,account_id) VALUES ('$hobby_name','$status','$userInSession')";

    if ($conn->query($insert_hobby) === TRUE) {
      header('location:hobbies.php');
    } else {
      echo 'query error' . mysqli_error($conn);
    }
  // }
}

?>

<?php include('header.php'); ?>

<div class="bg-white">
  <div class="container">
    <div class="row p-5">

      <div class="col-lg-8 col-sm-12">
        <div class="card text-center">
          <div class="card-header">
            <h4 class="card-title text-primary">Hobbies</h4>
          </div>
          <div class="card-body"> <?php echo json_encode($tb_hobbies ) ?>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Status</th>
                  <th scope="col" colspan="2">Action</th>
                </tr>
              </thead>
              <?php foreach ($tb_hobbies as $key => $value) { ?>
                <tr>
                  <th scope="row"><?php echo $value['hobby_name']; ?></th>
                  <td>Larry</td>
                  <td>the Bird</td>
                  <td>rer</td>
                </tr>
                <?php  } ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>

      <div class="col-lg-1 col-sm-12"></div>

      <div class="col-lg-3 col-sm-12">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title text-primary">Hobbies</h4>

            <form action="" method="post">
              <div class="form-group">
                <label for="hobby" class="text-muted font-weight-bold">Hobby:</label>
                <input type="text" id="hobby" class="form-control form-control-sm" name="hobby_name" placeholder="add a hobby" autofocus="true" required>
              </div>

              <br>

              <div class="form-group">
                <label for="status" class="text-muted font-weight-bold">status:</label>
                <select id="status" class="form-control form-control-sm" name="status" autofocus="true" required>
                  <option> </option>
                  <option value="1" class="text-success font-weight-bold">active</option>
                  <option value="0" class="text-danger font-weight-bold">inactive</option>
                </select>
              </div>

              <br>

              <div class="text-center">
                <input type="submit" name="hobby" value="Add New Hobby" class="btn btn-sm text-white text-center btn-primary">
              </div>

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php include('footer.php'); ?>
