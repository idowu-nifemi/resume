<?php
  $serverUrl = "https://api.covid19api.com/"
?>